﻿define("epi-cms/contentediting/command/CreateDraft", [
    "dojo/_base/declare",
    "epi-cms/contentediting/command/_ContentCommandBase",
    "epi-cms/contentediting/ContentActionSupport",

//Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons"
],

function (
    declare,
    _ContentCommandBase,
    ContentActionSupport,
    resources
) {

    return declare([_ContentCommandBase], {
        // summary:
        //      Create a draft version out of the current content
        //
        // tags:
        //      internal

        name: "createdraft",
        label: resources.createdraft.label,
        tooltip: resources.createdraft.title,
        iconClass: "epi-iconPage",

        contentActionSupport: null,

        postscript: function () {
            this.inherited(arguments);
            this.contentActionSupport = this.contentActionSupport || ContentActionSupport;
        },

        _execute: function () {
            // summary:
            //    Executes this command; create a new draft version out of the current content
            //
            // tags:
            //		protected

            this.model.createDraft();
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute after the model has been updated.
            // tags:
            //		protected

            this.inherited(arguments);

            var contentData = this.model.contentData,
                status = contentData.status,
                versionStatus = ContentActionSupport.versionStatus,
                hasAccessRights = this.contentActionSupport.isActionAvailable(contentData, ContentActionSupport.action.Create, ContentActionSupport.providerCapabilities.Create) &&
                                  this.contentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel[ContentActionSupport.action.Edit]);

            var canExecute = hasAccessRights && // The user has to have sufficient access rights AND
                    (((status == versionStatus.Published || status == versionStatus.PreviouslyPublished) && !contentData.isCommonDraft) || // The status is publish or previously published, and it's the common draft OR
                    status == versionStatus.DelayedPublish); // The status is delayed publish

            this.set("canExecute", canExecute);
            this.set("isAvailable", canExecute);
        }
    });

});